import React from "react";

const InputSubject = () => {
  return <div>과목 정보 입력창</div>;
};

export default InputSubject;
