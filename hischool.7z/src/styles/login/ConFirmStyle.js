import styled from "@emotion/styled";

const ConFirmWrap = styled.div``;
const ConFirmInput = styled.div``;
const ConFirmButtons = styled.div``;

export { ConFirmWrap, ConFirmInput, ConFirmButtons };
