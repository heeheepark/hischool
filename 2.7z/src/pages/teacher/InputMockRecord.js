import React from "react";

const InputMockRecord = () => {
  return <div>모의고사 성적 입력창</div>;
};

export default InputMockRecord;
