import React from "react";
import TeacherMyPage from "../components/teacher/TeacherMyPage";
// import StudentMypage from "../components/student/StudentMypage";

const Mypage = () => {
  return (
    <div>
      <TeacherMyPage />
      {/* <StudentMypage/> */}
    </div>
  );
};

export default Mypage;
